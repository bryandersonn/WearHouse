﻿using Microsoft.AspNetCore.Mvc;

namespace WearHouse.Controllers
{
    public class AboutUsController : Controller
    {
        public IActionResult AboutWearHouse()
        {
            return View();
        }
    }
}
