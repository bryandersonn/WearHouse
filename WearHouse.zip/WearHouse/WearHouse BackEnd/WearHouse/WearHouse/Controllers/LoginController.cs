﻿using Microsoft.AspNetCore.Mvc;
using WearHouse.Data;
using WearHouse.Models.Domain;
using WearHouse.Models;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;

namespace WearHouse.Controllers
{
    public class LoginController : Controller
    {

        private readonly WearHouseData wearHouseData;

        public LoginController(WearHouseData wearHouseData)
        {
            this.wearHouseData = wearHouseData;
        }

        [HttpGet]
        public IActionResult UserLogin()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UserLogin(LoginUserViewModel model)
        {
            var users = await wearHouseData.Users.ToListAsync();
            
            bool isCredentialsValid = false;
            foreach (var user in users)
            {
                if (user.Email == model.Email && user.Password == model.Password)
                {
                    isCredentialsValid = true;
                    break;
                }
            }

            if (isCredentialsValid)
            {
                return RedirectToAction("Dash", "Dashboard");
            }
            else
            {
                return View("UserLogin");
            }
        }

    }
}
