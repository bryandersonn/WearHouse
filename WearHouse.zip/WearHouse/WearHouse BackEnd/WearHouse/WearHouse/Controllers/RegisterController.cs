﻿using Microsoft.AspNetCore.Mvc;
using WearHouse.Data;
using WearHouse.Models;
using WearHouse.Models.Domain;

namespace WearHouse.Controllers
{
    public class RegisterController : Controller
    {
        private readonly WearHouseData wearHouseData;

        public RegisterController(WearHouseData wearHouseData)
        {
            this.wearHouseData = wearHouseData;
        }

        [HttpGet]
        public IActionResult UserRegister()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UserRegister(AddUserViewModel AddUserRequest)
        {
            var user = new User()
            {
                Id = Guid.NewGuid(),
                Name = AddUserRequest.Name,
                Email = AddUserRequest.Email,
                Password = AddUserRequest.Password
            };

            await wearHouseData.Users.AddAsync(user);
            await wearHouseData.SaveChangesAsync();
            return RedirectToAction("UserRegister");
        }
    }
}
