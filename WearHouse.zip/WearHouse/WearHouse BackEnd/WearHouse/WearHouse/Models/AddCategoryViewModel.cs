﻿namespace WearHouse.Models
{
    public class AddCategoryViewModel
    {
        public string CategoryName { get; set; }
    }
}
