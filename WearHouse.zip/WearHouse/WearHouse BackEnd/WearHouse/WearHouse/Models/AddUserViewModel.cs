﻿namespace WearHouse.Models
{
    public class AddUserViewModel
    {
        public string Name { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }
    }
}
