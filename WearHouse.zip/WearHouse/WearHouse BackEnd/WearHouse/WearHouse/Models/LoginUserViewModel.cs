﻿namespace WearHouse.Models
{
    public class LoginUserViewModel
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }
}
