﻿namespace WearHouse.Models
{
    public class UpdateCategoryViewModel
    {
        public Guid Id { get; set; }
        public string CategoryName { get; set; }
    }
}
