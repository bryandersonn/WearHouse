const hamburger = document.querySelector(".hamburger img");
const navbarItems = document.querySelector(".space");
const main = document.querySelector("main");
const footer = document.querySelector("footer");
const topshadow = document.querySelector(".top");


hamburger.addEventListener('click', () =>
{
    navbarItems.classList.toggle('active')
    main.classList.toggle('active')
    footer.classList.toggle('active')
    topshadow.classList.toggle('active')
})

const adminButton = document.querySelector(".admin-content");
const dropdown = document.querySelector(".dropdown");

adminButton.addEventListener('click', () =>
{
    dropdown.classList.toggle('active')
})

const pressadd = document.querySelector(".addCategory");
const addpop = document.querySelector(".addpopup");
const bluroverlay = document.querySelector(".overlay")

pressadd.addEventListener('click', () =>
{
    addpop.classList.toggle('active')
    bluroverlay.classList.toggle('active')
})

const pressedit = document.querySelectorAll(".editCategory");
const editpop = document.querySelector(".editpopup")

for(let i = 0; i < pressedit.length; i++)
{
    pressedit[i].addEventListener('click', () =>
    {
        editpop.classList.toggle('active')
        bluroverlay.classList.toggle('active')
    })
    
}

const pressdel = document.querySelectorAll(".deleteCategory");
const editdel = document.querySelector(".delpopup")

for(let i = 0; i < pressdel.length; i++)
{
    pressdel[i].addEventListener('click', () =>
    {
        editdel.classList.toggle('active')
        bluroverlay.classList.toggle('active')
    })
}

const pressx = document.querySelectorAll(".close");

for(let i = 0; i < pressx.length; i++)
{
    pressx[i].addEventListener('click', () =>
    {
        addpop.classList.remove('active')
        editpop.classList.remove('active')
        editdel.classList.remove('active')
        bluroverlay.classList.remove('active')
    })
}